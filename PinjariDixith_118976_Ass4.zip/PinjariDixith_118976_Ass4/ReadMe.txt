Folder 'DandC' can be executed as a python module by running "python -i DandC" from console when in it's directory. 

It can also be launched by simply running launch.bat. 

'myModule.py' inside of folder 'DandC' contains functions generatePoints, mergeSort, naive and DandC. 
sort function works like this: sortedList = mergeSort(list, comparison_function) 
generate a set of points like this: points = generatePoints(amount, minX, maxX, minY, maxY) 
get closest points from a set like this: distance, point1, point2 = naive(points) or distance, point1, point2 = DandC(points)

'DandC' automatically prints a test for all these functions.