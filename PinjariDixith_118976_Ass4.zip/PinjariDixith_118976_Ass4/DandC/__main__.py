from myModule import *

#generatePoints(amount, minX, maxX, minY, maxY)
points=generatePoints(10,0,50,0,200)
print("Generated a list of points:")
print(points)

sortedByX = mergeSort(points,lambda a,b: a[0]<b[0])
print("Sorting list of points by their X coordinates:")
print(sortedByX)

distance,p1,p2 = DandC(points)
print("2 closest points found by Divide & Conquer:")
print(p1)
print(p2)
print("Distance between them: "+str(distance))

distance,p1,p2 = naive(points)
print("Result of naive algorithm (points might be different, if there are other pairs with smallest distance)")
print(p1)
print(p2)
print("Distance between them: "+str(distance))
print("\nGenerate a list of points using generatePoints(amount, minX, maxX, minY, maxY)")
print("Sort a list using mergeSort(list, comparison_function)")
print("Use Divide&Conquer: DandC(list_of_points)")
print("Use naive algorithm: naive(list_of_points)")
print("Both algorithms return distance (number) and 2 points (lists with X and Y cooridnates)")