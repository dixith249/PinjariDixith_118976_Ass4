import random #need this module for random point generation

def ceil(i):
    if i%1>0:
        return int(i//1)+1
    else:
        return int(i)

#Merge sort is also Divide & Conquer type of algorithm
def mergeSort(array, func=lambda a, b: a < b): #also takes an optional function used for comparison
    length = len(array) #Saving length of array in a variable
    if length <= 1: #Arrays of length 1 are already sorted
        return array
    length = ceil(length / 2) #Divide array into 2 parts
    #Recursively sort both parts
    part1 = mergeSort(array[:length], func)
    part2 = mergeSort(array[length:], func)
    #Properly merge 2 sorted arrays together
    ind = 0
    for i in part1: #insert every element from part1 into part2
        while ind < len(part2):
            if func(i, part2[ind]): #Checking our function output
                part2.insert(ind, i) #then insert, moving elements of part2 forward
                break
            else: #if this is not proper place for inserting element from part1, then check next
                ind += 1
        else: #If reached end of part2, then just append to the end
            part2.append(i)
    return part2 #return sorted array

#Generates a list with given amount of points with given coordinate ranges
#Each point is a list with X and Y coordinates, both coordinates are integers
def generatePoints(amount, minX=0, maxX=100, minY=0, maxY=100):
    li = []
    for i in range(amount):
        point = []
        point.append(random.randint(minX, maxX))
        point.append(random.randint(minY, maxY))
        li.append(point)
    return li

def dist(p1, p2): #distance between 2 points
    return ((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)**0.5

#Function that finds 2 closest points checking distances pair by pair
# returns swallest distance between 2 points and those 2 points
def naive(points): #takes a list of points
    best1 = points[0]
    best2 = points[1]
    smallest = dist(best1, best2) #Initialize search with the first pair
    for i in range(len(points)): 
        for j in range(len(points)):
            d = dist(points[i], points[j]) #check all pairs one by one
            if i != j and smallest > d: #And find smallest
                smallest = d
                best1 = points[i]
                best2 = points[j]
    return smallest, best1, best2

#Function that finds 2 closest points using Divide & Conquer algorithm
# returns swallest distance between 2 points and those 2 points
def DandC(points): #takes a list of points
    if len(points) == 2: #if there are just 2 points, then we are done
        return dist(points[0], points[1]), points[0], points[1]
    elif len(points) == 3: #if there are just 3 points
        return naive(points) #can use naive algorithm for them
    points = mergeSort(points, lambda a, b: a[0]<b[0]) #We sort our list based on X coordinate
    mid = ceil(len(points)/2) #Ыplit our list into 2 halves
    d, p1, p2 = DandC(points[:mid]) #Recursively find closest points in both halves
    d2, p12, p22 = DandC(points[mid:])
    if d2 < d: #Take best of those 2
        d=d2
        p1=p12
        p2=p22
    #Now we need to check some points in between that might be better
    #Points are sorted by X, so we can take a slice
    start=0 #Start index of the slice
    end=len(points) #End index of the slice
    for i in range(len(points)): #Find first point that is closer to mid-point than d along X
        if abs(points[i][0]-points[mid][0]) < d: #In worst case in will be mid-point itself
            start = i
            break
    for i in range(mid+1, len(points)): #Now find first point after slice that is not close enough
        if abs(points[i][0]-points[mid][0]) >= d: #In worst case there's no such point, so end remains len(points)
            end = i
            break
    between = points[start:end] #Slice of potential better points
    between = mergeSort(between, lambda a, b: a[1]<b[1]) #Sort this list based on Y coordinate
    for i in range(len(between)):
        #Latter points are already checked with points before them, so start from i+1
        for j in range(i+1,len(between)): 
            if abs(between[i][1]-between[j][1]) >= d:
                break #Since points are sorted by Y, we can stop when too far away from this point
            newd=dist(between[i], between[j])
            if newd < d: #If found a better distance, replace old
                d = newd
                p1 = between[i]
                p2 = between[j]
    return d, p1, p2
    